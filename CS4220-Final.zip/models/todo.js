class ToDo {
    //private id:number;
    //private description: string;
    //private completed: boolean;
    constructor(_id, name, completed) {
        this._id = _id;
        this.name = name;
        this.completed = completed;
    }

}

module.exports = ToDo;